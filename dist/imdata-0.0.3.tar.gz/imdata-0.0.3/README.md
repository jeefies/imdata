# ImData

**Author: Jeef**  
**Email: jeefy163@163.com**

----------
## Installation
Use _git_ to clone it for the github.com.  
See [Github](https://github.com/jeefies/imdata)  
Or see [PyPI](https://pypi.org/project/imdata) to install  
`pip install imdata`.  
Notice that **All build files are under `dist`**

-------------
## Usage
the main class is ImData.  
_Dependeces: imageio_  
_Advice: Use python that later than 3.5, no support for 2.7_

Example usage see `test.py` for uses
